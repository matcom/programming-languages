﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WEBOO.LP
{
  class Fecha: IComparable<Fecha>
  {
    public int Dia { get; private set; }
    public int Mes { get; private set; }
    public int Año { get; private set; }

    public int CompareTo(Fecha f)
    {
      if (Año < f.Año) return -1;
      else if (Año > f.Año) return 1;
      if (Mes < f.Mes) return -1;
      else if (Mes > f.Mes) return 1;
      if (Dia < f.Dia) return -1;
      else if (Dia > f.Dia) return 1;
      else return 0;
    }

    public Fecha(int d, int m, int a)
    {
      Dia = d; Mes = m; Año = a;
    }
    public override string ToString()
    {
      return Dia + "/" + Mes + "/" + Año;
    }
    public override bool Equals(object obj)
    {
      Fecha f = obj as Fecha;
      if (f == null) return false;
      else return f.Dia == Dia && f.Mes == Mes && f.Año == Año;
    }
  }
}
