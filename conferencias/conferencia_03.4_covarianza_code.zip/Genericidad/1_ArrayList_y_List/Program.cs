﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;

namespace WEBOO.LP
{
  class Program
  {
    static void Main(string[] args)
    {
      #region PRUEBA CON ARRAYLIST y  LIST
      //ArrayList a = new ArrayList();
      ////Puedo meter cualquier tipo de objeto
      //a.Add(new Fecha(31, 12, 2013));
      //a.Add("rojo");
      ////Tengo que hacer un cast para usarlo
      //Console.WriteLine(( (Fecha)a[0] ).Dia);
      //Console.WriteLine(((string)a[1]).Contains("jo"));

      //List<Fecha> efemerides = new List<Fecha>();
      //List<string> colores = new List<string>();
      //efemerides.Add(new Fecha(10, 10, 2013));
      //colores.Add("amarillo");
      //Console.WriteLine(efemerides[0].Dia);
      //colores[0].Contains("jo");

      //Error de compilación
      //efemerides.Add("azul");
      //colores.Add(new Fecha(25, 12, 2013));
      #endregion

      #region PRUEBA DE ICOMPARABLE e ICOMPARABLE<FECHA>
      //Usarlo con las dos definiciones de Fecha, como IComparable y como IComparable<Fecha>
      Fecha f = new Fecha(1, 1, 2013);
      Console.WriteLine(f.CompareTo(new Fecha(28, 2, 2013)));

      //¿Error de compilación o excepción?
      //f.CompareTo("1/1/2013");

      //¿Error de compilación o excepción?
      //IComparable x = f;
      //Console.WriteLine(x.CompareTo(new Fecha(28, 2, 2013)));
      //Console.WriteLine(x.CompareTo("1/1/2013"));
      #endregion

    }
  }
}
