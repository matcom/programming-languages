﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WEBOO.Programacion
{
  public class Cuenta: IComparable<Cuenta>
  {
    public int Saldo { get; private set; }
    public string Propietario { get; private set; }

    public Cuenta(string propietario, int depositoInicial)
    {
      if (depositoInicial > 0) Saldo = depositoInicial;
      else throw new Exception("Deposito debe ser mayor que cero");
      Propietario = propietario;
    }

    //Deposita
    //Extrae

    public override string ToString()
    {
      return "Cuenta(" + Propietario + ", " + Saldo + ")";
    }

    public int CompareTo(Cuenta c)
    {
      if (Saldo < c.Saldo) return -1;
      else if (Saldo > c.Saldo) return 1;
      else return 0;
    }
  }
}
