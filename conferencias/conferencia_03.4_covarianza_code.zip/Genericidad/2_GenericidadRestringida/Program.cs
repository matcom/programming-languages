﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WEBOO.LP {
  static class Utilidades 
  {
    public static void Ordena<T>(T[] items) where T:IComparable<T>{
      for (int k = 0; k < items.Length - 1; k++)
        for (int j = k + 1; j < items.Length; j++)
          if (items[j].CompareTo(items[k]) < 0) {
            T temp = items[j];
            items[j] = items[k];
            items[k] = temp;
          }
    }
  }
  class Program {
    static void Main(string[] args)
    {
      Fecha[] efemerides = {new Fecha(1,1,2010),   new Fecha(31, 12, 2010), new Fecha(1,5,2011), 
                            new Fecha(25,12,2010), new Fecha(31,1,2009)};
      
      Console.WriteLine("\nEfemérides...");
      foreach (Fecha f in efemerides) Console.WriteLine(f);
      Utilidades.Ordena(efemerides);
      Console.WriteLine("\nFechas ordenadas");
      foreach (Fecha f in efemerides) Console.WriteLine(f);
      Console.ReadLine();
    }
  }
}
