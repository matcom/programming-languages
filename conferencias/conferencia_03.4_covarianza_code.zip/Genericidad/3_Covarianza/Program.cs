﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WEBOO.LP
{
  class Animal
  {
    public void Come()
    {
      Console.WriteLine("Cronch, Cronch ...");
    }
    public static void DarDeComer(IEnumerable<Animal> animales)
    {
      foreach (var a in animales) a.Come(); 
    }
  }
  class Perro: Animal
  {
    public void Ladra()
    {
      Console.WriteLine("Jau, Jau ...");
    }
  }
  class Gato : Animal
  {
    public void Maulla()
    {
      Console.WriteLine("Miau, Miau ...");
    }
  }

  class Program
  {
    
    static void Main(string[] args)
    {
      //Probar comentando y descomentando cada una de estas regiones por separado
      #region Los arrays son COVARIANTES
      //Animal[] animales = new Animal[5];
      //Perro[] perros = new Perro[] { new Perro(), new Perro(), new Perro() };
      //Gato tom = new Gato();
      //tom.Maulla();
      //perros[1].Ladra();
      //animales = perros;
      //animales[1].Come();

      ////animales[1].Ladra(); //ERROR de Compilación

      ////¿Qué pasa si hacemos
      ////perros[1] = tom; //ERROR de Compilación perros es un array de Perro

      ////Y si hacemos
      ////animales[1] = tom; //EXCEPCIÓN en runtime ¿Por qué?

      ////Si lo anterior da excepción se está impidiendo dar de comer a los animales
      //Animal.DarDeComer(animales);

      //////Pero si permitimos animales[1] = tom
      //////¿Qué pasa si hacemos
      ////foreach (var p in perros) p.Ladra();
      ////¿Puede encontrar un mejor balance en no ser muy restrictivo dando ERROR de compilación
      ////pero ser más seguros no dando EXCEPCIÓN en runtime

      #endregion

      #region List<T> NO es covariante
      //List<Animal> animales = new List<Animal>();
      //Gato Tom = new Gato();
      //Perro Pluto = new Perro();
      //animales.Add(Tom);
      //animales.Add(Pluto);
      //foreach (var a in animales) a.Come();
      //List<Perro> jauría = new List<Perro> { new Perro(), new Perro(), new Perro() };
      //foreach (var p in jauría)
      //{
      //  p.Ladra(); p.Come();
      //};
      //Console.WriteLine("Animales comiendo ...");
      //Animal.DarDeComer(animales);
      //Console.WriteLine("Jauría comiendo ...");
      //Animal.DarDeComer(jauría);
      //Console.WriteLine("Jauría ladrando ...");
      //foreach (var p in jauría) p.Ladra();

      ////Note que se permitió hace Animal.DarDeComer(jauría)
      ////Es decir pasarle un List<Perro> al parámetro DarDeComer
      ////Pero si hacemos
      ////animales = jauría;
      ////Da ERROR de compilación
      ////Para no permitir la potencial combinación
      ////animales.Add(Tom); //Colaría a TOM en la jauría
      ////...
      ////foreach (var p in jauría) p.Ladra();
      ////Pero SÍ se permite
      #endregion

      #region IEnumerable<T> SÍ es covariante
      //IEnumerable<Animal> animales;
      //List<Perro> perros = new List<Perro> { new Perro(), new Perro(), new Perro() };
      //animales = perros; //ASIGNACION COVARIANTE

      ////A través de animales no hay modo de colocar un Gato en la lista perros
      ////Error de compilación porque no hay una operación Add
      ////animales.Add(Tom);

      //foreach (var a in animales) a.Come();

      #endregion
    }
  }
}
