
#DICCIONARIOS
#dicc = {"nombre":"Pepe", "edad":20}
#print (dicc)
#print ("Mi nombre es ", dicc['nombre'])
#print ("Mi edad es ", dicc["edad"])

#class C:
#  None
#c=C()
#print ("Soy el objeto ", c)
#print ("El diccionario de c es ", c.__dict__)
#c.__dict__ = dicc
#print("Ahora c.nombre es ", c.nombre)
#print("Ahora c.edad es ", c.edad)
#c.salario = 10000
#print ("El diccionario de c ", c.__dict__)
#print ("Las variables de c son ")
#for x in c.__dict__.keys():
#  print (x)

#TUPLOS
#triplo = (300, 400, 500)
#print ("triplo es ", triplo)
#print ("triplo[0] es ", triplo[0])
#print ("triplo[1] es ", triplo[1])
#print ("triplo[2] es ", triplo[2])

##Lo puedo desagregar
#a, b, c = triplo
#print(a, b, c)

##print ("¿Puedo cambiar un item de un tuplo?")
##Ejecutar el siguiente código da errror
##triplo[1] = 600
##print (triplo[1])

#LISTAS
#nums = [100, 10, 200, 20, 300, 30, 400, 40]
#print (nums)
#for n in nums: print (n, end=' ')
#print()
#for i in range(len(nums)): print (nums[i], end=' ')
#print()
#nums.append('no soy numero')
#print (nums)

#mejunje = ["rojo", 10, True, (1, 2, 3), 4.25, None]
#print ("mejunje es", mejunje)
#mezcla = mejunje
##Probar que mezcla y mejunje son la misma lista
#mezcla[1] = "azul"
#print ("mejunje es ", mejunje)
#mejunje[2] = 1000
#print("mezcla es ", mezcla)
#print ("¿mezcla es igual mejunje?", mezcla == mejunje)

#COMBINANDO LISTAS Y TUPLOS
#nums = [100, 10, 200, 20, 300, 30, 400, 40]
#def MinMax(items):
#  if (len(items) == 0): return None
#  else:
#    min = max = items[0]
#    for x in items:
#      if (x > max): max = x
#      elif (x < min): min = x
#  return min, max
#minimo, maximo = MinMax(nums)
#print ("La lista es ", nums)
#print ("El minimo es ", minimo, "y el maximo es ", maximo)


##GENERADORES (ENUMERABLES)
##Un rango es un generador lazy
#intervalo = range(1, 5)
#print ("rango ", intervalo)
#print ("recorriendo el rango ", end='')
#for k in intervalo: print (k, end=' ')
#print()

##entre corchetes crea la lista
#lista = [k for k in range(1, 5)]
#print ("lista ", lista )

##entre llaves crea un diccionario
#dicc_cuadrados = {k:k*k for k in range(1,5)}
#print ("diccionario", dicc_cuadrados)

##entre paréntesis es un generador
#enum_cubos = (k*k*k for k in range(1, 5))
#print (enum_cubos)
#for n in enum_cubos: print (n, end=' ')
#print()

#CALCULANDO LONGITUD DE UN ITERADOR (ENUMERABLE)
#class DummyClass:
#  None
#def ParesGenerator(n):
#  x = 0
#  while x <= n:
#    yield x
#    x+=2
#def Length(items):
#  if type(items) == list: return len(items)
#  elif type(items) == dict: return len(items)
#  elif type(items) == tuple: return len(items)
#  elif type(items) == range: 
#    #No se le puede aplicar len hay que contarlos
#    n = 0
#    for x in items: n+=1
#    return n
#  else: #Otra cosa que no sabemos si es iterable
#    try:
#      iter(items) #si items no es iterable da excepción
#    except TypeError: return (None, "non iterable object") 
#    else:
#      k = 0
#      for x in items: k+=1
#      return k
#nums = range(1,10)
#lista_cuadrados = [k*k for k in nums]
#dicc_triplos = {k: 3*k for k in nums}
#tupla_cubos = (k*k*k for k in nums)
#pares = ParesGenerator(1000);
#print (Length(nums))
#print (Length(lista_cuadrados))
#print (Length(dicc_triplos))
#print (Length(tupla_cubos))
##Un string es iterable"
#print (Length("cáscara"))
##Objeto iterable
#print (Length(ParesGenerator(1000)))
##Este objeto no iterable
#print (Length(DummyClass()))
