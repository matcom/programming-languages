﻿#VARIABLES
#No hay declaración estática el tipo lo determina el valor de la variable
#print ("Bienvenido a Python")
#x = 23
#print (x)
#x = "abc"
#print (x)

##Debe dar error en runtime porque no se puede concatenar el entero 1 a un string
##print (x+1)

#PROBANDO LOS ÁMBITOS Y LAS VARIABLES
#Ir comentando y descomentando los códigos pero dejar siempre este segmento de código
x = "Valor del x del módulo"
class A:
  x = "Valor del x de la clase A"
  #print (x)
  def M():
   x = "Valor del x del método M de A"
   print ("Soy M de A escribiendo x")
   print (x)

def M():
  print ("Soy M del módulo escribiendo x")
  print (x)

#print (x)
#M()
#A.M()
#print (A.x)
#a1 = A()
#print (a1.x)
#print (x)

#M()
#A.M()
#a1 = A()
#a1.M()
#Esto da error porque a1.M() se interpreta como A.M(a1) y el método M no tiene parámetros

##Le estamos definiendo a a1 su propio x
#a1 = A()
#a1.x = "Valor del x de a1"
#a2 = a1 #a2 y a1 tienen como valor el mismo objeto
#print (x)
#print (A.x)
#print (a1.x)
#print (a2.x)
#a2.x = "Valor del x de a2"
#print (a1.x)
#print (a2.x)

##Un atributo de un objeto se puede referir al mismo objeto
#a1 = A()
#print (a1)
#a1.b = A()
#print (a1.b)
#a1.b.b = A()
#print (a1.b.b)
#a1.b.b.b = a1
#print (a1.b.b.b)

#COMO LOGRAR UNA LLAMADA CON NOTACION OBJETUAL
#class B:
#  def M(x):
#    print ("Han llamado a B.M(x)")
#    print ("x es ",  x)

#B.M("parámetro en llamada imperativa")
#b = B()
#b.M()
##Ver que tipo de error da esto
##b = "otrovalor"
##b.M()

##CÓMO LOGRAR EL EFECTO VARIABLES DE INSTANCIA Y EL EFECTO CONSTRUCTOR
#class Punto:
#  #Método especial que se aplica al hacer Punto() crear un objeto Punto 
#  def __init__(self): 
#    self.x = 0 #x hará las veces de variable de instancia de Punto
#    self.y = 0 #y hará las veces de variable de instancia de Punto
#  def QuienSoy(self):
#    print ("Soy el punto ", self)
#    print ("(",self.x,",",self.y,")")
  
#p1 = Punto()
#p1.QuienSoy()
#p2 = Punto()
#p2.QuienSoy()
#p2.x = 100
#p2.y = 200
#p1.QuienSoy()
#p2.QuienSoy()

##NO hay tipado estático que garantice que los valores de x y y sean int
#p1.y = "ya no soy un int"
#p1.QuienSoy()
#p2.QuienSoy()

#CÓMO LOGRAR EL EFECTO DE PONERLE PARÁMETROS AL CONSTRUCTOR
#class Punto:
#  #Método especial que se aplica al hacer Punto() crear un objeto Punto 
#  def __init__(self, x, y): 
#    self.x = x 
#    self.y = y 
#  def QuienSoy(self):
#    print ("Soy el punto ", self)
#    print ("(",self.x,",",self.y,")")
  
#p1 = Punto(200, 500)
#p1.QuienSoy()

##coord2D = (100, 300)
##p2 = Punto(*coord2D) #Le pedimos a la tupla que se despliegue. Tiene que matchear con la cantidad de parámetros
##p2.QuienSoy()

##coord3D = (100, 200, 300) #Da error porque no matchea la cantidad de parametros
##p3 = Punto(*coord3D)

#OPERADOR __call__
#class D:
#  count = 0
#  def __init__(self):
#    D.count = D.count + 1
#    self.id = D.count
#  def __call__(self):
#    print ("Soy ",self.id,
#           "me han llamado directamente")
#  def M(self):
#    print ("Soy ",self.id,"Llamando a M")
#  def F(self):
#    print ("Soy ",self.id,"Llamando a F")

#d1 = D()
#d1()
#d2 = D()
#d2()
#d1.M()
#d1.F()
#d2.M()
#d2.F()
###cual es el resultado de lo siguiente?
##D()()

#AMBITO (SCOPE) DE LAS VARIABLES
#class C:
#  count = 0
#  def __init__(self):
#    C.count = C.count + 1
#    self.id = C.count
#    self.count = 0 #Para contar cuantas llamadas se hacen a un objeto
#    print("Se han creado ", C.count, "objetos")
#  def M(self):
#    print ("Soy obj",self.id,"Llamando a M")
#    self.count = self.count+1
#    print ("Llamada ", self.count)
#  def F(self):
#    print ("Soy obj",self.id,"Llamando a F")
#    self.count = self.count+1
#    print ("Llamada ", self.count)

#c1 = C()
#c2 = C()
#c1.M()
#c1.F()
#c2.M()
#c1.M()
#c3 = C()
#c3.M()


#USO DE DICCIONARIOS PARA DEFINIR LOS SCOPES
#class A:
#  x = 100
#Las siguientes operaciones dan el mismo resultado
#print (A.x)
#print(A.__dict__["x"])
#print(getattr(A, "x"))

#a=A()
#a.y = 200
#print (a.y)
#print(a.__dict__["y"])
#print(getattr(a, "y"))
#print (a.x) #x no es variable propia de a lo busca en A
##print(a.__dict__["x"]) #Da excepcion x no es atributo de a
#setattr(a,"x",500) #nueva variable para la instancia a
#print (a.x)
#setattr(a,"x",600) #nueva variable para la instancia a
#print (a.x)
#a.x = 700
#print (a.x)
#print (A.x)

#DEFINIENDO VARIABLES A LAS INSTANCIAS USANDO EL DICCIONARIO
class C:
  x = 100

print(C.x)
print(C.__dict__["x"])
print(getattr(C, "x"))
print()

c = C()
print (c.x) #este es el x de C
setattr(c,"x",500) 
print ("La variable x de c ", c.x)
c.x = 1000
print ("La variable x de c ", c.x)
print ("La variable x de C ", C.x)
