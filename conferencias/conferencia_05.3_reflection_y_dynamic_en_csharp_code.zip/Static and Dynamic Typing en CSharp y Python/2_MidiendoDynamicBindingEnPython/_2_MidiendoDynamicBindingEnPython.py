import time
import random
import math

##HERENCIA Y JERARQUIA DE FIGURAS
class Punto:
  def __init__(self, x, y): 
    self.x = x
    self.y = y

def dist(p, q):
  return math.sqrt((p.x - q.x)**2 + (p.y-q.y)**2)

class Figura:
  def Area(self): return 0
  def __init__(self, p): 
    self.p = p
  def Perimetro(self): return 0
  def QuienSoy(self): 
    return
  def NoHagoNada(self):
    return
  def Traslada(self, dx, dy):
    self.p.x+=dx
    self.p.y+=dy
  def MisProporciones(self):
    print("Tengo Area ", self.Area() , 
          " y Perimetro ", self.Perimetro())

class Rectangulo(Figura):
  def Area(self): return self.ancho*self.alto
  #...
  def __init__(self, p1, ancho, alto):
    super().__init__(p1)
    self.ancho = ancho
    self.alto = alto
  def Perimetro(self): return (self.ancho+self.alto)*2
  def QuienSoy(self): 
    print ("Soy Rectangulo")
    self.MisProporciones()

class Circulo(Figura):
  def Area(self): return math.pi*self.radio*self.radio
  #...
  def __init__(self, p1, r):
    super().__init__(p1)
    self.radio = r
  def Perimetro(self): return 2*math.pi*self.radio
  def QuienSoy(self): 
    print ("Soy Circulo")
    self.MisProporciones()

#1 MIDIENDO TIEMPO DE DYNAMIC BINDING EN PYTHON   
#while (True):
#  if random.choice([True, False]):
#    f = Rectangulo(Punto(100, 100), 10, 20)
#  else: 
#    f = Circulo(Punto(200, 200), 50 )
#  n = int(input("Entra cantidad de veces a repetir "))
#  if (n==0): break
#  start = time.time()
#  for x in range(n): 
#    f.NoHagoNada()
#  end = time.time()
#  print ("Tiempo en Python por ", n," llamadas dynamic binding a NoHagoNada ",
#         int((end - start)*1000), " ms")
#  start = time.time()
#  for x in range(n): 
#    None #solo para medir repeticion sin llamar a nadie
#  end = time.time()
#  print ("Tiempo solo por repetir el mismo ciclo ", n, " veces sin hacer llamadas ",
#         int((end - start)*1000), " ms")

##2 PROBANDO REUSABILIDAD COLOCANDO UN TRIANGULO QUE NO HEREDA DE FIGURA A UNA LISTA JUNTO CON RECTANGULOS Y CIRCULOS
##Comentar bloque anterior para probar este
class Triangulo:
  def __init__(self, p1, p2, p3):
    self.p1 = p1
    self.p2 = p2
    self.p3 = p3
  def Perimetro(self): 
    return dist(self.p1,self.p2)+dist(self.p2,self.p3)+dist(self.p3,self.p1)
  def Area(self): 
    sp = self.Perimetro()/2
    #Area de un triangulo
    return math.sqrt(sp*(sp-dist(self.p1,self.p2))*(sp-dist(self.p2,self.p3))
                       *(sp-dist(self.p3,self.p1)))

def MayorFigura(list):
  mayorArea = 0
  mayor = None
  for x in list:
    if (x.Area()>mayorArea): 
      mayor = x
      mayorArea = x.Area()
  return (mayor, mayorArea)

figuras = [Circulo(Punto(200, 200), 10 ), Rectangulo(Punto(100, 100), 100, 20),
           Triangulo(Punto(10,20),Punto(120,130), Punto(130, 20)), Circulo(Punto(200, 200), 30 ) ]
fig, area = MayorFigura(figuras)
print ("La figura de mayor es ", fig, " su area es ", area)

while (True):
  n = int(input("Entra cantidad de veces a repetir "))
  if (n==0): break
  start = time.time()
  for k in range(n):
    fig, area = MayorFigura(figuras)
  end = time.time()
  print ("Tiempo en Python por ", n," llamadas dynamic binding a MayorFigura(figuras) es ",
        int((end - start)*1000), " ms")
##Probar también tiempo contra solucion de C# usando casting

#PROBANDO RESOLUCION DE NOMBRES EN PYTHON
#def F():
#  print("Soy metodo F de ningunan clase")

#class C:
#  def M(self):
#    print("Soy metodo en M en la clase C")
#  def __init__(self): 
#    None

#class C1(C):
#  def __init__(self): 
#    self.M = F

#class C2(C):
#  None

#class C3(C):
#  def M(self):
#    print("Soy metodo en M en la clase C3")
#  def __init__(self):
#    None

#c  =  C()
#c1 = C1()
#c2 = C2()
#c3 = C3()
#c.M()
#c1.M()
#c2.M()
#c3.M()
