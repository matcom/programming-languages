﻿using System;

namespace LP
{
  public interface TengoArea
  {
    double Area();
  }
}
