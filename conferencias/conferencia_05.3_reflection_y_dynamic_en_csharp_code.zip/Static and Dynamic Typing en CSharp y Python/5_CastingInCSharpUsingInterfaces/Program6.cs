﻿using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace LP
{
  #region CLASES DE FIGURAS
  class Punto
  {
    public int X, Y;
    public Punto(int x, int y)
    {
      X = x; Y = y;
    }
    public double Dist(Punto p)
    {
      return Math.Sqrt((X - p.X) * (X - p.X) + (Y - p.Y) * Y - p.Y);
    }
  }
  abstract class Figura: TengoArea
  {
    Punto vertice;
    public Figura(Punto p)
    {
      vertice = p;
    }
    public abstract double Area();
    public abstract double Perimetro();
    public abstract void NoHaceNadaConLateBinding();
    public void NoHaceNadaConEarlyBinding() { }
    public void Traslada(int dX, int dY)
    {
      vertice = new Punto(vertice.X + dX, vertice.Y + dY);
    }
    public void QuienSoy()
    {
      Console.WriteLine("Soy un {0} de Area {1} y de Perimetro ", GetType().Name, Area(), Perimetro());
    }
  }
  class Rectangulo : Figura
  {
    int Ancho;
    int Alto;
    public Rectangulo(Punto p, int ancho, int alto) : base(p)
    {
      Ancho = ancho;
      Alto = alto;
    }
    public override double Area()
    {
      return Ancho * Alto;
    }
    public override void NoHaceNadaConLateBinding()
    {

    }
    public override double Perimetro()
    {
      return 2 * (Ancho + Alto);
    }
  }
  class Circulo : Figura
  {
    int Radio;
    public Circulo(Punto p, int radio) : base(p)
    {
      Radio = radio;
    }
    public override double Area()
    {
      return 3.141592 * Radio * Radio;
    }
    public override double Perimetro()
    {
      return 2 * 3.141592 * Radio;
    }
    public override void NoHaceNadaConLateBinding()
    {

    }
  }
  class Triangulo: TengoArea //No hereda de Figura pero implementa Area
  {
    Punto v1, v2, v3;
    public Triangulo(Punto p1, Punto p2, Punto p3)
    {
      v1 = p1; v2 = p2; v3 = p3;
    }
    public double Area()
    {
      //Cálculo del área por la fórmula de Herón
      var sp = Perimetro() / 2;
      return Math.Sqrt(sp * (sp - v1.Dist(v2)) *
                            (sp - v2.Dist(v3)) *
                            (sp - v3.Dist(v1)));
    }
    public double Perimetro()
    {
      return v1.Dist(v2) + v2.Dist(v3) + v3.Dist(v1);
    }
  }
  #endregion

  class Program3
  {
    static void Main(string[] args)
    {

     
      #region LOGRANDO DYNAMIC TYPING CON UNA INTERFACE MAS GENERAL
      //Para probar esto comentar la región anterior
      (TengoArea, double) MayorFig(List<TengoArea> figs)
      {
        TengoArea mayor = null;
        double mayorArea = 0;
        foreach (var x in figs)
        {
          if (x is TengoArea)
          {
            TengoArea f = (TengoArea)x;
            if (f.Area() > mayorArea)
            {
              mayorArea = f.Area();
              mayor = f;
            }
          }
          else 
          {
            //No lo consideramos cuando no tiene Area
          }
        }
        return (mayor, mayorArea);
      }
      var figuras = new List<TengoArea>();
      Random r = new Random();
      int ancho = 10;
      int radio = 10;
      int verticeX = 0;
      int verticeY = 0;
      for (int i = 1; i <= 4; i++)
      {
        int k = r.Next(3);
        if (k == 0)
          figuras.Add(new Rectangulo(new Punto(100, 100), ancho += 10, 20));
        else if (k == 1)
          figuras.Add(new Circulo(new Punto(200, 200), radio += 2));
        else
          figuras.Add(new Triangulo(new Punto(verticeX += 5, verticeY += 10),
                                      new Punto(120, 130),
                                      new Punto(130, 20)));
      }
      object fig; double area;
      (fig, area) = MayorFig(figuras);
      Console.WriteLine("La mayor figura es un {0} con area {1}", fig.GetType().Name, area);

      Stopwatch crono = new Stopwatch();
      while (true)
      {
        Console.WriteLine("Entre cantidad de veces a repetir");
        var s = Console.ReadLine();
        long n;
        if (!(long.TryParse(s, out n))) break;
        Console.WriteLine("Calculando MayorFigura usando Reflection " + n + " veces..");
        crono.Restart();
        for (long k = 1; k <= n; k++)
        {
          (fig, area) = MayorFig(figuras);
        }
        long time = crono.ElapsedMilliseconds;
        Console.WriteLine("Tiempo " + time + " ms");
      }
      #endregion
    }
  }
}