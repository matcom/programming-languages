﻿using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace LP
{
  #region PRODUCTOR MISTERIOSO
  //Un tipo desconocido pero que tiene Area
  public class TipoMisterioso
  {
    public double Area()
    {
      return 888888;
      //Un valor cualquiera
    }
    //public void M()
    //{
    //  return; //No hace nada
    //}
  }
  public class ProductorMisterioso
  {
    public object Produce()
    {
      return new TipoMisterioso();
    }
  }
  #endregion
}