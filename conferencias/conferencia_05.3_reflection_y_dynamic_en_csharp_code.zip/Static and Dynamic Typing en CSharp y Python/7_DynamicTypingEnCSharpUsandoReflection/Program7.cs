﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;

//Reflection es un namespace que contiene los tipos para hacer reflection
//Con esto se puede hacer introspección del código de una DLL o un exe para reconstruir toda la maquinaria de .NET
//De hecho el propio compilador es un usuario de Reflection cuando analiza el código de las DLLs formen parte de un proyecto
//Recomendamos analice, curiosee y pruebe sus propios ejemplos usando Reflection
//VER PROPUESTA DE TAREA AL FINAL DEL CÓDIGO

namespace LP
{
  #region CLASES DE FIGURAS
  class Punto
  {
    public int X, Y;
    public Punto(int x, int y)
    {
      X = x; Y = y;
    }
    public double Dist(Punto p)
    {
      return Math.Sqrt((X - p.X) * (X - p.X) + (Y - p.Y) * Y - p.Y);
    }
  }
  abstract class Figura
  {
    Punto vertice;
    public Figura(Punto p)
    {
      vertice = p;
    }
    public abstract double Area();
    public abstract double Perimetro();
    public void Traslada(int dX, int dY)
    {
      vertice = new Punto(vertice.X + dX, vertice.Y + dY);
    }
    public void QuienSoy()
    {
      Console.WriteLine("Soy un {0} de Area {1} y de Perimetro ", GetType().Name, Area(), Perimetro());
    }
  }
  class Rectangulo : Figura
  {
    int Ancho;
    int Alto;
    public Rectangulo(Punto p, int ancho, int alto) : base(p)
    {
      Ancho = ancho;
      Alto = alto;
    }
    public override double Area()
    {
      return Ancho * Alto;
    }
    public override double Perimetro()
    {
      return 2 * (Ancho + Alto);
    }
  }
  class Circulo : Figura
  {
    int Radio;
    public Circulo(Punto p, int radio) : base(p)
    {
      Radio = radio;
    }
    public override double Area()
    {
      return 3.141592 * Radio * Radio;
    }
    public override double Perimetro()
    {
      return 2 * 3.141592 * Radio;
    }
  }
  class Triangulo //No hereda de Figura
  {
    Punto v1, v2, v3;
    public Triangulo(Punto p1, Punto p2, Punto p3)
    {
      v1 = p1; v2 = p2; v3 = p3;
    }
    public double Area()
    {
      //Cálculo del área por la fórmula de Herón
      var sp = Perimetro() / 2;
      return Math.Sqrt(sp * (sp - v1.Dist(v2)) *
                            (sp - v2.Dist(v3)) *
                            (sp - v3.Dist(v1)));
    }
    public double Perimetro()
    {
      return v1.Dist(v2) + v2.Dist(v3) + v3.Dist(v1);
    }
  }
  #endregion

  class Program7
  {
    //Se probará una función que recibe una lista de objetos que supuestamente tienen un método Area
    //Y se devolverá el tipo del objeto que tiene la mayor Area y el valor retornado por el Area en cuestión
    static void Main(string[] args)
    {
      (object, double) MayorFig(List<object> figs)
      {
        //De la lista de objetos desconocidos hallar cual tiene mayor Area
        //de entre los que tienen Area
        object mayor = null;
        double mayorArea = 0;
        //Recorrer los potenciales objetos que tienen area
        foreach (var f in figs)
        {
          try
          {
            //Note que en la lista que se le pasará más abajo a MayorFig pueden venir objetos que no tengan un método Area
            //Si no tiene un método Area el Invoke a continuación dará excepción
            double area = (double)f.GetType().GetMethod("Area").Invoke(f, null);
            
            //Descomente el código a continuación si quiere ver los nombres de los tipos que tienen método Area
            //Console.WriteLine("Tipo {0}", f.GetType().Name);

            //Se presupone que el método Area no tiene parámetos, de ahí el pasarle null
            //Si tuviese parámetros había que pasarle un array object[] con los parámetros
            if (area > mayorArea)
            {
              mayorArea = area;
              mayor = f;
            }
          }
          catch
          {
            //Escribir el tipo del objeto que no tiene un método de signatura double Area()
            //Comentar la linea siguiente cuando se quiere medir el tiempo que pone el dynamic
            //Console.WriteLine("Tipo {0} No tiene método Area", f.GetType().Name);

            //En este ejemplo lo que se ha hecho es seguir recorriendo los objetos de la lista
            //Los que no tienen Area no se considerarán la respuesta
          }
        }
        return (mayor, mayorArea);
      }

      #region CARGANDO UN PRODUCTOR DE OBJETOS QUE PUEDEN O NO TENER AREA
      Assembly assam = null;
      object factory = null;
      try
      {
        Console.WriteLine("\nEntre nombre de fichero DLL");
        string file = Console.ReadLine();
        //De la cual no tiene que estar el código fuente en el proyecto
        //Para probar debe darsele el nombre del archivo donde está la DLL que contiene
        //la clase ProductorMisterioso
        assam = Assembly.LoadFrom(file);
        //Carga en memoria un ensamblado (la DLL en cuestion)
      }
      catch
      {
        throw new Exception("Nombre de DLL incorrecto");
      }
      Type[] types = assam.GetExportedTypes();
      //Nos da un array con objetos tipo Type que corresponden a las clases public que hay en la DLL
      bool existeProductor = false;
      //Recorrer los tipos que hay en el ensamblado
      foreach (Type t in types)
      {
        //Buscar si alguno de los tipos tiene un método de nombre Produce
        foreach (var m in t.GetMethods())
        {
          if (m.Name == "Produce")
          {
          //Crear un objeto del tipo que tiene el método Produce
          //Tengo que saber qué parámetros ponerle al constructor
          //Para simplificar en este ejemplo el constructor del tipo no tiene parámetros
          factory = t.GetConstructor(new Type[0]).Invoke(null); 
          //Queda entonces en factory un objeto de tipo ProductorMisterioso
          existeProductor = true;
          break;
         }
        }
      }
      if (!existeProductor)
        throw new Exception("En esta DLL no hay ningún tipo con método Produce");
      #endregion

      #region CREANDO UNA LISTA DE OBJETOS ALEATORIOS QUE PUEDEN O NO TENER AREA PARA CALCULAR MAYOR AREA
      var figuras = new List<object>();
          Random r = new Random();
          int ancho = 10;
          int radio = 10;
          int verticeX = 0;
          int verticeY = 0;
          figuras.Add(factory.GetType().GetMethod("Produce").Invoke(factory, new object[0]));
          //Garantizar que en el array hay un tipo misterioso
          for (int i = 1; i <= 3; i++)
          {
            int k = r.Next(6);
            if (k == 0)
              figuras.Add(new Rectangulo(new Punto(100, 100), ancho += 10, 20));
            else if (k == 1)
              figuras.Add(new Circulo(new Punto(200, 200), radio += 2));
            else if (k == 2)
              figuras.Add(new Triangulo(new Punto(verticeX += 5, verticeY += 10),
                                          new Punto(120, 130),
                                          new Punto(130, 20)));
            else if (k == 3)
            figuras.Add(factory.GetType().GetMethod("Produce").Invoke(factory, new object[0]));
            //Al objeto factory de tipo ProductorMisterioso se le invoca el método Produce
            //Para simplificar se ha considerado que el método Produce no tiene parámetros de ahí el new object[0]
            //De lo contrario había que pasar en Invoke un array con los objetos de los parámetros del dicho Método
            else if (k == 4)
              figuras.Add("Soy un string no tengo Area");
            
            //Si descomenta el siguiente código anterior daría error de compilación
            //porque UnTipoMisterioso no es public, nos se puede crear directamente un objetoso de UnTipoMisterioso
            //Sin embargo en la opción de arriba usando reflectios se ha podido colocar en la lista un objeto de UnTipoMisterioso
            //else if (k == 5)
            //  figuras.Add(new UnTipoMisterioso());
          }
          object fig; double area;
          (fig, area) = MayorFig(figuras);
          Console.WriteLine("La mayor figura es un {0} con area {1}", fig.GetType().Name, area);
          Console.ReadLine();

          //Para medir el tiempo usando Reflection
          Stopwatch crono = new Stopwatch();
          while (true)
          {
            Console.WriteLine("Entre cantidad de veces a repetir");
            var s = Console.ReadLine();
            long n;
            if (!(long.TryParse(s, out n))) break;
            Console.WriteLine("Calculando MayorFigura usando Reflection " + n + " veces..");
            crono.Restart();
            for (long k = 1; k <= n; k++)
            {
              (fig, area) = MayorFig(figuras);
            }
            long time = crono.ElapsedMilliseconds;
            Console.WriteLine("Tiempo " + time + " ms");
          }
      #endregion

    }
  }
}

//PROBLEMA PROPUESTO
//USANDO REFLECTION RECONSTRUYA ESTE EJEMPLO PARA HACERLO MAS GENERICO
//QUE EL METODO SEA ALGO ASÍ COMO
//  object Mayor(IEnumerable<object> objs) basándose en que los objetos o son IComparables o tienen
//  un método bool MayorQue(object x)
//  un bono para examen para el primero que traiga una respuesta correcta
