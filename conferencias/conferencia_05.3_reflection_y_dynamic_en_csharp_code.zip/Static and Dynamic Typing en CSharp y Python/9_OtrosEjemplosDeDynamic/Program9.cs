﻿using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace LP
{
  class Punto
  {
    public int X, Y;
    public Punto(int x, int y)
    {
      X = x; Y = y;
    }
    public double Dist(Punto p)
    {
      return Math.Sqrt((X - p.X) * (X - p.X) + (Y - p.Y) * Y - p.Y);
    }
  }
  class Rectangulo
  {
    int Ancho;
    int Alto;
    Punto supIzq;
    public Rectangulo(Punto p, int ancho, int alto)
    {
      supIzq = p;
      Ancho = ancho;
      Alto = alto;
    }
    public double Area()
    {
      return Ancho * Alto;
    }
    public double Perimetro()
    {
      return 2 * (Ancho + Alto);
    }
  }
  class Program9
  {
    static void Main(string[] args)
    {
      #region DIFERENTES USOS DEL DYNAMIC
      dynamic d;
      Random rand = new Random();
      while (true)
      {
        switch (rand.Next(5))
        {
          case 0:
            d = 1000;
            break;
          case 1:
            d = "Real Madrid";
            break;
          case 2:
            d = new Rectangulo(new Punto(10, 20), 30, 20);
            break;
          case 3:
            d = new int[] { 3, 5, 7, 11, 13 };
            break;
          default:
            d = new Func<int, int, int>((x, y) => x * y);
            break;
        }

        Console.WriteLine("Yo soy {0}", d);
        try
        {
          int k = d;
          Console.WriteLine("Como soy int me puedo sumar 5 = {0} ", k + 5);
        }
        catch { }
        try
        {
          string s = d;
          Console.WriteLine("Como soy string {0} mi longitud es {1}", s, s.Length);
        }
        catch { }
        try
        {
          Console.WriteLine("Como soy Rectangulo mi área {0} es ", d.Area());
        }
        catch { }
        try
        {
          int[] a = d;
          Console.WriteLine("Como soy array mi 4to elemento es {0}", a[3]);
        }
        catch { }
        try
        {
          Console.WriteLine("Como soy una multiplicación la llamada d(5,100) es {0}", d(5, 100));
        }
        catch { }
        //Pausa
        Console.ReadLine();
      }
      #endregion
    }
  }
}
