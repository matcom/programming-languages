﻿using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace LP
{
  #region CLASES DE FIGURAS
  class Punto
  {
    public int X, Y;
    public Punto(int x, int y)
    {
      X = x; Y = y;
    }
    public double Dist(Punto p)
    {
      return Math.Sqrt((X - p.X) * (X - p.X) + (Y - p.Y) * Y - p.Y);
    }
  }
  abstract class Figura
  {
    Punto vertice;
    public Figura(Punto p)
    {
      vertice = p;
    }
    public abstract double Area();
    public abstract double Perimetro();
    public abstract void NoHaceNadaConLateBinding();
    public void NoHaceNadaConEarlyBinding() { }
    public void Traslada(int dX, int dY)
    {
      vertice = new Punto(vertice.X + dX, vertice.Y + dY);
    }
    public void QuienSoy()
    {
      Console.WriteLine("Soy un {0} de Area {1} y de Perimetro ", GetType().Name, Area(), Perimetro());
    }
  }
  class Rectangulo : Figura
  {
    int Ancho;
    int Alto;
    public Rectangulo(Punto p, int ancho, int alto) : base(p)
    {
      Ancho = ancho;
      Alto = alto;
    }
    public override double Area()
    {
      return Ancho * Alto;
    }
    public override void NoHaceNadaConLateBinding()
    {

    }
    public override double Perimetro()
    {
      return 2 * (Ancho + Alto);
    }
  }
  class Circulo : Figura
  {
    int Radio;
    public Circulo(Punto p, int radio) : base(p)
    {
      Radio = radio;
    }
    public override double Area()
    {
      return 3.141592 * Radio * Radio;
    }
    public override double Perimetro()
    {
      return 2 * 3.141592 * Radio;
    }
    public override void NoHaceNadaConLateBinding()
    {

    }
  }

  class Triangulo //No hereda de Figura
  {
    Punto v1, v2, v3;
    public Triangulo(Punto p1, Punto p2, Punto p3)
    {
      v1 = p1; v2 = p2; v3 = p3;
    }
    public double Area()
    {
      //Cálculo del área por la fórmula de Herón
      var sp = Perimetro() / 2;
      return Math.Sqrt(sp * (sp - v1.Dist(v2)) *
                            (sp - v2.Dist(v3)) *
                            (sp - v3.Dist(v1)));
    }
    public double Perimetro()
    {
      return v1.Dist(v2) + v2.Dist(v3) + v3.Dist(v1);
    }
  }
  #endregion

  class Program1
  {
    static void Main(string[] args)
    {
      #region MIDIENDO TIEMPO de EARLY y LATE BINDING
      Figura f;
      Random r = new Random();
      if (r.Next(2) == 1) f = new Rectangulo(new Punto(100, 100), 10, 20);
      else f = new Circulo(new Punto(200, 200), 50);
      Stopwatch crono = new Stopwatch();
      while (true)
      {
        Console.WriteLine("Entre cantidad de veces a repetir");
        var s = Console.ReadLine();
        long n;
        if (!(long.TryParse(s, out n))) break;
        Console.WriteLine("Tiempo llamada (no hacer nada) con late binding " + n + " veces..");
        crono.Restart();
        for (long k = 1; k <= n; k++)
        {
          f.NoHaceNadaConLateBinding();//No hace nada pero hace latebinding
        }
        long time = crono.ElapsedMilliseconds;
        Console.WriteLine("Tiempo " + time + " ms");
        Console.WriteLine("Tiempo llamada (no hacer nada) con early binding " + n + " veces..");
        crono.Restart();
        for (long k = 1; k <= n; k++)
        {
          f.NoHaceNadaConEarlyBinding();//No hace nada pero hace early binding
        }
        time = crono.ElapsedMilliseconds;
        Console.WriteLine("Tiempo " + time + " ms");
      }
      #endregion
    }
  }
}
