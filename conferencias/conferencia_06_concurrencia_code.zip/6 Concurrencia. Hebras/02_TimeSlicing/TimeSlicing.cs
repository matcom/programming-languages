﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Diagnostics;

namespace WEBOO.LP
{
  class Program
  {
    static int tiempo;
    public static void Plus()
    {
      for (int k = 0; k < 10; k++)
      {
        Thread.Sleep(tiempo);
        Console.WriteLine("{0, 2}, Hebra +++", k);
      }
    }
    public static void Minus()
    {
      for (int k = 0; k < 10; k++)
      {
        Thread.Sleep(tiempo*2);
        Console.WriteLine("{0, 2}, Hebra ---", k);
      }
    }
    public static void Mult()
    {
      for (int k = 0; k < 10; k++)
      {
        Thread.Sleep(tiempo*4);
        Console.WriteLine("{0, 2}, Hebra ***", k);
      }
    }

    static void Main(string[] args)
    {
      //Descomente y vaya probando cada región

      #region PROBANDO TIME SLICING
      //Comente region anterior para ejecutar esta
      while (true)
      {
        Console.WriteLine("Entre cantidad de ms a dormir cada hebra ");
        string s = Console.ReadLine();
        if (s.Length == 0) break;
        tiempo = int.Parse(s);
        Thread thread1 = new Thread(Plus);
        Thread thread2 = new Thread(Minus);
        Thread thread3 = new Thread(Mult);
        thread1.Start();
        thread2.Start();
        thread3.Start();
        Console.WriteLine("Terminó Main");
      }
      #endregion
    }
  }
}

