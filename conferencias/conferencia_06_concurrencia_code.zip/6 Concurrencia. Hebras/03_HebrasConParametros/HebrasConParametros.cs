﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Diagnostics;

namespace WEBOO.LP
{
  class Program
  {
    
    #region FIBONACCI
    //CUANDO SE EJECUTA POR DISTINTAS HEBRAS CADA UNA TIENE SU STACK FRAME
    public static long Fib(int n)
    {
      if ((n == 1) || (n == 2)) return 1;
      else return Fib(n - 1) + Fib(n - 2);
    }
   
    public static void Fibonacci(object x)
    { 
      Stopwatch cronoHebra = new Stopwatch();
      //El método Start de una hebra tiene un parámetro object para que se le pueda pasar cualquier cosa
      //Es responsabilidad de la hebra interpretarlo como espera que deba ser, de lo contrario lo siguiente dará excepción de ejecución
      //en este ejemplo se supone que es el número entero para el que se quiere calculas Fibonacci
      int n = (int)x;
      cronoHebra.Restart();
      long result = Fib(n);
      cronoHebra.Stop();
      //Comentar lo que sigue si no queremos que el WriteLine pese en el costo global
      Console.WriteLine(
        "Hebra {0} calculó Fibonacci de {1} = {2,10} en {3} ms",
         Thread.CurrentThread.Name, n, result,
         cronoHebra.ElapsedMilliseconds);

    }
    #endregion

    static void Main(string[] args)
    {
      #region VARIAS HEBRAS CALCULANDO FIBONACCI. CADA HEBRA TIENE SU STACK FRAME PARA SUS DATOS
      Stopwatch cronoGlobal = new Stopwatch();
      while (true)
      {
        //Probar con diferentes valores para cada hebra
        //Probar con un mismo valor (ejemplo 35) para observar que con hebras hay mayor rendimiento que secuencial 
        Console.Write("Entre número a calcular Fib1 ");
        int n1 = Int32.Parse(Console.ReadLine());
        Console.Write("Entre número a calcular Fib2 ");
        int n2 = Int32.Parse(Console.ReadLine());
        Console.Write("Entre número a calcular Fib3 ");
        int n3 = Int32.Parse(Console.ReadLine());
        Console.Write("Entre número a calcular Fib4 ");
        int n4 = Int32.Parse(Console.ReadLine());
        cronoGlobal.Restart();
        var r1 = Fib(n1);
        var r2 = Fib(n2);
        var r3 = Fib(n3);
        var r4 = Fib(n4);
        cronoGlobal.Stop();
        Console.WriteLine("Fib de {0} = {1}", n1, r1);
        Console.WriteLine("Fib de {0} = {1}", n2, r2);
        Console.WriteLine("Fib de {0} = {1}", n3, r3);
        Console.WriteLine("Fib de {0} = {1}", n4, r4);
        Console.WriteLine("Tiempo global para calcular los 4 Fibonacci secuencialmente {0} ms", cronoGlobal.ElapsedMilliseconds);
        Thread Fib1 = new Thread(Fibonacci);
        Thread Fib2 = new Thread(Fibonacci);
        Thread Fib3 = new Thread(Fibonacci);
        Thread Fib4 = new Thread(Fibonacci);
        Fib1.Name = "Fib1"; Fib2.Name = "Fib2";
        Fib3.Name = "Fib3"; Fib4.Name = "Fib4";
        Console.WriteLine("Iniciando las hebras ...");
        cronoGlobal.Restart();
        //Se le pasa un parámetro a cada hebra
        Fib1.Start(n1); Fib2.Start(n2); Fib3.Start(n3); Fib4.Start(n4);
        //Esperar porque terminen todas las 4 hebras
        Fib1.Join(); Fib2.Join(); Fib3.Join(); Fib4.Join();
        cronoGlobal.Stop();
        Console.WriteLine("Entre todas hemos terminado en {0} ms", cronoGlobal.ElapsedMilliseconds);
      }
      #endregion
    }
  }
}

