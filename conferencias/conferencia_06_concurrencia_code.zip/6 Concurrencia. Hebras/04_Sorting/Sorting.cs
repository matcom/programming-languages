﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Diagnostics;

namespace WEBOO.LP
{
  //PROYECTO PARA PRACTICA EN CASA
  class Programa
  {

    #region ARRAY METHODS

    public static void Sort(object x) //Para usar como hebra parametrizada
    {
      int[] a = (int[])x;
      //PROBAR CON LAS DOS OPCIONES

      ////OPCION 1 USANDO SORT Este es de orden N*LgN
      //Array.Sort(a); 

      ////OPCION 2 ORDENANDO FUERZA BRUTA N*N (no probar con mas de 10000
      for (int i = 0; i < a.Length - 1; i++) //
      {
        for (int j = i + 1; j < a.Length; j++)
        {
          if (a[j] < a[i])
          {
            int temp = a[i];
            a[i] = a[j];
            a[j] = temp;
          }
        }
      }
    }

    public static int[] CreateRandomArray(int n)
    {
      int[] a = new int[n];
      Random r = new Random();
      for (int k = 0; k < n; k++)
        a[k] = r.Next(n);
      return a;
    }
    #endregion

    static void Main(string[] args)
    {
      #region PROBANDO QUE LAS HEBRAS APROVECHAN EL PARALELISMO
      while (true)
      {
        Console.Write("Entre tamaño del array ");
        string s = Console.ReadLine();
        if (s.Length == 0) break;
        int n = int.Parse(s);
        Console.WriteLine("Creando 6 arrays iguales ...");
        int[] a1 = CreateRandomArray(n); 
        var a2 = (int[])a1.Clone(); 
        var a3 = (int[])a1.Clone();
        var b1 = (int[])a1.Clone();
        var b2 = (int[])a1.Clone();
        var b3 = (int[])a1.Clone();
        Console.WriteLine("\nOrdenando 3 de los arrays secuencialmente ...");
        Stopwatch crono = new Stopwatch(); ;
        crono.Restart();
        Sort(a1); Sort(a2); Sort(a3);
        crono.Stop();
        Console.WriteLine("Tiempo en ordenar los 3 secuencialmente {0} ms",
                           crono.ElapsedMilliseconds);
        Thread sort1 = new Thread(Sort);
        Thread sort2 = new Thread(Sort);
        Thread sort3 = new Thread(Sort);
        crono.Restart();
        sort1.Start(b1); sort2.Start(b2); sort3.Start(b3);
        //Esperando porque terminen las hebras        
        sort1.Join(); sort2.Join(); sort3.Join();
        crono.Stop();
        Console.WriteLine("Tiempo en ordenar los 3 con 3 hebras {0} ms",
                          crono.ElapsedMilliseconds);
      }
      #endregion
    }
  }
}