﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace WEBOO.LP {
  
  class Asientos {
    int asientos;
    public Asientos(int totalPlazas) {
      asientos = totalPlazas;
    }
    public bool HayPlazas()
    {
      return asientos > 0;
    }
    public int DameAsiento()
    {
      if (asientos > 0)
        return asientos--;
      else throw new Exception("No hay plazas disponibles");
    }
  }

  class Taquilleria
  {
    Asientos BD; //La base de datos con la disponibilidad de asientos la comparten todos los vendedores
    public Taquilleria(Asientos bd)
    {
      this.BD = bd;
    }

    //PROBAR CON CADA UNA DE LAS OPCIONES DE VENDEDOR COMENTANDO Y DESCOMENTANDO LA OPCION CORRESPONDIENTE

    #region VENDEDOR SIN SINCRONIZACION
    //public void Vendedor(object x) //Vendedor recibe un parámetro int que indica su velocidad de venta
    //{
    //  int demoraEnHacerUnaVenta = (int)x;
    //  int vendidos = 0;
    //  Console.WriteLine("{0} Empieza a vender ...",
    //                    Thread.CurrentThread.Name);
    //  while (BD.HayPlazas())
    //  {
    //    Thread.Sleep(demoraEnHacerUnaVenta);
    //    Simular demora en hacer venta
    //    Console.WriteLine("{0} vende asiento {1}",
    //                      Thread.CurrentThread.Name, BD.DameAsiento());
    //    vendidos++;
    //  }
    //  Console.WriteLine("!!! {0} cerró con {1} asientos vendidos",
    //                    Thread.CurrentThread.Name, vendidos);
    //}
    #endregion

    #region VENDEDOR CON SINCRONIZACIÓN IMPERFECTA
    //public void Vendedor(object x)
    //{
    //  int demoraEnHacerUnaVenta = (int)x;
    //  int vendidas = 0;
    //  while (BD.HayPlazas())
    //  {
    //    lock (BD) 
    //    //Bloquea el recurso antes de intentar modificarlo. Si otra hebra intenta usarlo queda interrumpida
    //    //El recurso se libera cuando se termina la ejecución del bloque indicado por el lock
    //    {
    //      Thread.Sleep(demoraEnHacerUnaVenta); //Simular demora
    //      Console.WriteLine("{0} vende la plaza {1}",
    //                        Thread.CurrentThread.Name, BD.DameAsiento());
    //      vendidas++;
    //    }
    //  }
    //  Console.WriteLine("!!! {0} vendió {1} asientos",
    //                    Thread.CurrentThread.Name, vendidas);
    //}
    #endregion

    #region VENDEDOR CON SINCRONIZACIÓN CORRECTA
    ////Probar con esta opción de Vendedor para mejor sincronización
    public void Vendedor(object x)
    {
      int demoraEnHacerUnaVenta = (int)x;
      int vendidas = 0;
      while (true)
      {
        lock (BD) //Se trata de cerrar el candado
        {
          if (BD.HayPlazas())
          {
            Thread.Sleep(demoraEnHacerUnaVenta);
            Console.WriteLine("{0} vende la plaza {1}",
              Thread.CurrentThread.Name, BD.DameAsiento());
            vendidas++;
          }
          else
          {
            Console.WriteLine("!!! {0} vendió {1} plazas",
              Thread.CurrentThread.Name, vendidas);
            break;
          }
        }
      }
    }
    #endregion

  }//Taquillerias

  class Program {
    static void Main(string[] args) {

      #region Varios vendedores concurrentes sobre una misma Base de Datos
      while (true)
      {
        Console.Write("\nEntre cantidad de asientos (solo enter para terminar) -> ");
        string s = Console.ReadLine();
        if (s.Length == 0) break;
        int plazas = int.Parse(s);
        Asientos BD = new Asientos(plazas);
        Taquilleria teatroNacional = new Taquilleria(BD);
        Thread lala = new Thread(teatroNacional.Vendedor);
        lala.Name = "Lala";
        Thread lili = new Thread(teatroNacional.Vendedor);
        lili.Name = "Lili";
        Thread lulu = new Thread(teatroNacional.Vendedor);
        lulu.Name = "Lulu";
        //Probar con distintas velocidades de venta cada una
        //Probar con 30 asientos
        lala.Start(10); 
        lili.Start(10);
        lulu.Start(10);
        lala.Join(); lili.Join(); lulu.Join();
        Console.WriteLine("\nTodas las plazas vendidas");
      }
      #endregion
    }
  }
}
