﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Threading;

namespace WEBOO.LP {
  class Program {
    static Random r = new Random();
    static Tenedor[] tenedores;
    class Tenedor { }
    public static void Filosofo(object parTenedores) 
    {
      int vecesComiendo = 0;
      int izq = ((Tuple<int, int>)parTenedores).Item1;
      int der = ((Tuple<int, int>)parTenedores).Item2;
      while (true) {
        Console.WriteLine("{0, -30}{1}", "Pensando ...", 
          Thread.CurrentThread.Name);
        Thread.Sleep(r.Next(40));
        Console.WriteLine("{0,-30}{1}", "Queriendo comer ...", 
          Thread.CurrentThread.Name);
        lock (tenedores[izq]) {
          Thread.Sleep(r.Next(20)); //Demora en coger el otro tenedor ir probando de 20 para abajo
          lock (tenedores[der]) {
            vecesComiendo++;
            Console.WriteLine("{0}{1}{2, -19}{3}", 
              "Comiendo ", vecesComiendo, "...", Thread.CurrentThread.Name);
            Thread.Sleep(r.Next(20));
          }
        }
      }
    }
    static void Main(string[] args) {
      tenedores = new Tenedor[5];
      for (int k = 0; k < tenedores.Length; k++) 
        tenedores[k] = new Tenedor();
      var seneca = new Thread(Filosofo);
      seneca.Name = "Séneca";
      var platon = new Thread(Filosofo);
      platon.Name = "Platón";
      var aristoteles = new Thread(Filosofo);
      aristoteles.Name = "Aristóteles";
      var diogenes = new Thread(Filosofo);
      diogenes.Name = "Diógenes";
      var socrates = new Thread(Filosofo);
      socrates.Name = "Sócrates";
      seneca.Start(new Tuple<int, int>(0, 1));
      platon.Start(new Tuple<int, int>(1, 2));
      aristoteles.Start(new Tuple<int, int>(2, 3));
      diogenes.Start(new Tuple<int, int>(3, 4));
      socrates.Start(new Tuple<int, int>(4, 0));
    }
  }
}

//TAREA
//PROBAR DANDO TAMBIEN LA OPCION DE DAR PARAMETROS PARA TIEMPO COMIENDO Y TIEMPO PENSANDO PARA CADA FILOSOFO
//BUSQUE UNA SOLUCION PARA EVITAR EL DEADLOCK