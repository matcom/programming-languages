﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Diagnostics;

namespace WEBOO.LP {
  class Program {
    public static void HebraA()
    {
      for (int k=0; k<10; k++)
      {
        Console.WriteLine("{0,2} Hebra A ...", k);
      }
    }
    public static void HebraB()
    {
      for (int k = 0; k < 10; k++)
      {
        Console.WriteLine("{0,2} Hebra B ...", k);
      }
    }

    static void Main(string[] args)
    {
      //Descomente y vaya probando cada región

      #region TIME SLICING BASICO
      Thread thread1 = new Thread(HebraA);
      Thread thread2 = new Thread(HebraB);
      thread1.Start();
      thread2.Start();
      for (int k = 0; k < 10; k++)
      {
        Console.WriteLine("{0,2} Hebra Main ...", k);
      }
      #endregion
    }
  }
}
